import { Component, type ErrorInfo, type ReactNode } from 'react';

/** 错误边界属性 */
export type ErrorBoundaryProps = {
  /** 渲染错误时降级展示的内容 */
  readonly fallback?: ReactNode;
  /** 渲染错误回调（遥测上报等），错误发生时调用 */
  readonly onError?: (error: Error, info?: ErrorInfo) => void;
  /** 子内容 */
  readonly children: ReactNode;
};

/** 错误边界状态 */
type ErrorBoundaryState = {
  /** 是否已发生渲染错误 */
  readonly hasError: boolean;
};

/**
 * 渲染错误边界：子组件抛出渲染错误时降级为 fallback 并回调 onError
 *
 * React 错误边界只能以 class 组件实现，本组件是框架层共享的错误兜底
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {

  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  override componentDidCatch(error: Error, info: ErrorInfo) {
    this.props.onError?.(error, info);
  }

  override render() {
    if (this.state.hasError) {
      return this.props.fallback ?? null;
    }
    return this.props.children;
  }

}
