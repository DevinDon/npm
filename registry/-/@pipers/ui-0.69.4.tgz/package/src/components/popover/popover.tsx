'use client';

import { type ComponentProps } from 'react';
import { Popover as PopoverPrimitive } from '@base-ui/react/popover';

import { cn } from '@/lib/utils.mjs';

export const Popover = ({ ...props }: PopoverPrimitive.Root.Props) => <PopoverPrimitive.Root data-slot='popover' { ...props } />;

export const PopoverTrigger = ({ ...props }: PopoverPrimitive.Trigger.Props) => <PopoverPrimitive.Trigger data-slot='popover-trigger' { ...props } />;

export const PopoverContent = ({
  className,
  align = 'center',
  alignOffset = 0,
  side = 'bottom',
  sideOffset = 4,
  ...props
}: PopoverPrimitive.Popup.Props
  & Pick<
    PopoverPrimitive.Positioner.Props,
    'align' | 'alignOffset' | 'side' | 'sideOffset'
  >) => (
  <PopoverPrimitive.Portal>
    <PopoverPrimitive.Positioner
      align={ align }
      alignOffset={ alignOffset }
      side={ side }
      sideOffset={ sideOffset }
      className='isolate z-50'
    >
      <PopoverPrimitive.Popup
        data-slot='popover-content'
        className={ cn(
          'z-50 flex w-72 origin-(--transform-origin) flex-col gap-2.5 rounded-lg bg-popover p-2.5 text-sm text-popover-foreground shadow-md ring-1 ring-foreground/10 outline-hidden duration-150 data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95',
          className,
        ) }
        { ...props }
      />
    </PopoverPrimitive.Positioner>
  </PopoverPrimitive.Portal>
);

export const PopoverHeader = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='popover-header'
    className={ cn('flex flex-col gap-0.5 text-sm', className) }
    { ...props }
  />
);

export const PopoverTitle = ({ className, ...props }: PopoverPrimitive.Title.Props) => (
  <PopoverPrimitive.Title
    data-slot='popover-title'
    className={ cn('font-medium', className) }
    { ...props }
  />
);

export const PopoverDescription = ({
  className,
  ...props
}: PopoverPrimitive.Description.Props) => (
  <PopoverPrimitive.Description
    data-slot='popover-description'
    className={ cn('text-muted-foreground', className) }
    { ...props }
  />
);
