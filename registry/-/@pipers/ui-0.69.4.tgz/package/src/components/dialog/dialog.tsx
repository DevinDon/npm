import { type ComponentProps } from 'react';
import { Dialog as DialogPrimitive } from '@base-ui/react/dialog';

import { cn } from '@/lib/utils.mjs';
import { Button } from '@/components/button/index.mjs';
import { XIcon } from 'lucide-react';

export const Dialog = ({ ...props }: DialogPrimitive.Root.Props) => <DialogPrimitive.Root data-slot='dialog' { ...props } />;

export const DialogTrigger = ({ ...props }: DialogPrimitive.Trigger.Props) => <DialogPrimitive.Trigger data-slot='dialog-trigger' { ...props } />;

export const DialogPortal = ({ ...props }: DialogPrimitive.Portal.Props) => <DialogPrimitive.Portal data-slot='dialog-portal' { ...props } />;

export const DialogClose = ({ ...props }: DialogPrimitive.Close.Props) => <DialogPrimitive.Close data-slot='dialog-close' { ...props } />;

export const DialogOverlay = ({
  className,
  ...props
}: DialogPrimitive.Backdrop.Props) => (
  <DialogPrimitive.Backdrop
    data-slot='dialog-overlay'
    className={ cn(
      'fixed inset-0 isolate z-50 bg-black/10 duration-150 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0',
      className,
    ) }
    { ...props }
  />
);

export const DialogContent = ({
  className,
  children,
  showCloseButton = true,
  ...props
}: DialogPrimitive.Popup.Props & {
  showCloseButton?: boolean;
}) => (
  <DialogPortal>
    <DialogOverlay />
    <DialogPrimitive.Popup
      data-slot='dialog-content'
      className={ cn(
        'fixed top-1/2 left-1/2 z-50 grid w-full max-w-[calc(100%-2rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-popover p-4 text-sm text-popover-foreground ring-1 ring-foreground/10 duration-150 outline-none sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95',
        className,
      ) }
      { ...props }
    >
      { children }
      { showCloseButton && (
        <DialogPrimitive.Close
          data-slot='dialog-close'
          render={
            (<Button
              variant='ghost'
              className='absolute top-2 right-2'
              size='icon-sm'
            />)
          }
        >
          <XIcon />
          <span className='sr-only'>Close</span>
        </DialogPrimitive.Close>
      ) }
    </DialogPrimitive.Popup>
  </DialogPortal>
);

export const DialogHeader = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='dialog-header'
    className={ cn('flex flex-col gap-2', className) }
    { ...props }
  />
);

export const DialogFooter = ({
  className,
  showCloseButton = false,
  children,
  ...props
}: ComponentProps<'div'> & {
  showCloseButton?: boolean;
}) => (
  <div
    data-slot='dialog-footer'
    className={ cn(
      '-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t border-t-border bg-muted/50 p-4 sm:flex-row sm:justify-end',
      className,
    ) }
    { ...props }
  >
    { children }
    { showCloseButton && (
      <DialogPrimitive.Close render={ <Button variant='outline' /> }>
        Close
      </DialogPrimitive.Close>
    ) }
  </div>
);

export const DialogTitle = ({ className, ...props }: DialogPrimitive.Title.Props) => (
  <DialogPrimitive.Title
    data-slot='dialog-title'
    className={ cn(
      'font-heading text-base leading-none font-medium',
      className,
    ) }
    { ...props }
  />
);

export const DialogDescription = ({
  className,
  ...props
}: DialogPrimitive.Description.Props) => (
  <DialogPrimitive.Description
    data-slot='dialog-description'
    className={ cn(
      'text-sm text-muted-foreground *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground',
      className,
    ) }
    { ...props }
  />
);
