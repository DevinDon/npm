import { cn } from '@/lib/utils.mjs';
import { type ComponentProps } from 'react';

export const Kbd = ({ className, ...props }: ComponentProps<'kbd'>) => (
  <kbd
    data-slot='kbd'
    className={ cn(
      "pointer-events-none inline-flex h-5 w-fit min-w-5 items-center justify-center gap-1 rounded-sm bg-muted px-1 font-sans text-xs font-medium text-muted-foreground select-none in-data-[slot=tooltip-content]:bg-background/20 in-data-[slot=tooltip-content]:text-background dark:in-data-[slot=tooltip-content]:bg-background/10 [&_svg:not([class*='size-'])]:size-3",
      className,
    ) }
    { ...props }
  />
);

export const KbdGroup = ({ className, ...props }: ComponentProps<'div'>) => (
  <kbd
    data-slot='kbd-group'
    className={ cn('inline-flex items-center gap-1', className) }
    { ...props }
  />
);

