import { mergeProps } from '@base-ui/react/merge-props';
import { type ComponentProps } from 'react';
import { useRender } from '@base-ui/react/use-render';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/lib/utils.mjs';
import { Separator } from '@/components/separator/index.mjs';

export const buttonGroupVariants = cva(
  "flex w-fit items-stretch *:focus-visible:relative *:focus-visible:z-10 has-[>[data-slot=button-group]]:gap-2 has-[select[aria-hidden=true]:last-child]:[&>[data-slot=select-trigger]:last-of-type]:rounded-r-lg [&>[data-slot=select-trigger]:not([class*='w-'])]:w-fit [&>input]:flex-1",
  {
    variants: {
      orientation: {
        horizontal:
          '*:data-slot:rounded-r-none [&>[data-slot]:not(:has(~[data-slot]))]:rounded-r-lg! [&>[data-slot]~[data-slot]]:rounded-l-none [&>[data-slot]~[data-slot]]:border-l-0',
        vertical:
          'flex-col *:data-slot:rounded-b-none [&>[data-slot]:not(:has(~[data-slot]))]:rounded-b-lg! [&>[data-slot]~[data-slot]]:rounded-t-none [&>[data-slot]~[data-slot]]:border-t-0',
      },
    },
    defaultVariants: {
      orientation: 'horizontal',
    },
  },
);

export const ButtonGroup = ({
  className,
  orientation,
  ...props
}: ComponentProps<'div'> & VariantProps<typeof buttonGroupVariants>) => (
  <div
    role='group'
    data-slot='button-group'
    data-orientation={ orientation }
    className={ cn(buttonGroupVariants({ orientation }), className) }
    { ...props }
  />
);

export const ButtonGroupText = ({
  className,
  render,
  ...props
}: useRender.ComponentProps<'div'>) => useRender({
  defaultTagName: 'div',
  props: mergeProps<'div'>(
    {
      className: cn(
        "flex items-center gap-2 rounded-lg border bg-muted px-2.5 text-sm font-medium [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4",
        className,
      ),
    },
    props,
  ),
  render,
  state: {
    slot: 'button-group-text',
  },
});

export const ButtonGroupSeparator = ({
  className,
  orientation = 'vertical',
  ...props
}: ComponentProps<typeof Separator>) => (
  <Separator
    data-slot='button-group-separator'
    orientation={ orientation }
    className={ cn(
      'relative self-stretch bg-input data-horizontal:mx-px data-horizontal:w-auto data-vertical:my-px data-vertical:h-auto',
      className,
    ) }
    { ...props }
  />
);

