# @pipers/logger

多格式（`colorful-text` / `plain-text` / `inline-json`）、多目标（stdout / stderr 可多路）、运行期可改级别、支持 child bindings 与 redact 脱敏的日志工具。

## 安装

```bash
pnpm add @pipers/logger
```

## 使用

```ts
import { createLogger } from '@pipers/logger';

const logger = createLogger({ format: 'plain-text' });
logger.info?.('服务已启动');

// child：注入固定 bindings（如请求 id、链路 id）
const requestLogger = logger.child({ id: '#abc123' });
```

- `format`：`'colorful-text'`（默认）| `'plain-text'` | `'inline-json'`
- `target`：单目标对象或多目标数组；`warn` / `error` / `fatal` 走 stderr
- `redact`：按点号路径脱敏（不修改输入对象）
- 日志写失败会被吞掉，不影响业务；生产代码请用 `logger` 而非 `console`

## 文档与变更

- 使用指南：https://github.com/DevinDon/pipers/blob/main/docs/README.md
- 变更记录（含破坏性变更与迁移对照）：https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md

## 许可

MIT © IInfinity
