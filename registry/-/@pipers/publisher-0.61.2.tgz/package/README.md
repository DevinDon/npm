# @pipers/publisher

将 npm 包发布到静态 registry（GitHub Pages 托管）的工具。连打包带推送：把指定项目打包为标准 npm tarball + 生成 registry metadata，推送到指定 GitHub 仓库；安装方只需一行 `.npmrc` 即可用正常 semver 依赖安装。

## 为什么

- 不想去 npmjs.com 发布包，保持自托管（GitHub Pages 静态托管）
- 旧模式（裸 URL 依赖）版本写死、升级麻烦；本工具生成的 metadata 让 pnpm/npm 按 registry 协议解析

## 安装与用法

```bash
# 打包指定项目（生成 tgz + metadata 到临时目录）
publisher pack <project> --registry-url https://npm.iinfinity.io

# 推送临时目录中的产物到 GitHub 仓库（token 从 GH_TOKEN 环境变量读取，兼容 GITHUB_TOKEN）
publisher push --repo devindon/npm --branch main --registry-url https://npm.iinfinity.io

# 一步完成（CI 推荐用法）
publisher publish <project> --repo devindon/npm --registry-url https://npm.iinfinity.io

# 清理临时目录
publisher clean
```

### 环境变量（配置项，均可被 CLI 参数覆盖）

| 变量 | 说明 | 默认 |
|------|------|------|
| `GH_TOKEN` | GitHub Token（推送必需；未设置时回退读取 `GITHUB_TOKEN`） | 无 |
| `PUBLISHER_REGISTRY_URL` | registry 域名根 | `https://npm.iinfinity.io` |

### 安装方配置

```ini
# .npmrc
@pipers:registry=https://npm.iinfinity.io
```

```json
{ "dependencies": { "@pipers/toolkit": "^0.60.41" } }
```

## 产物布局（npm 官方 registry 布局）

```text
registry/-/<name>-<version>.tgz   # tarball（tgz，统一放 registry/-/ 目录，避免与 metadata 路径冲突）
registry/<name>                   # registry metadata（无扩展名，scoped 包为 @scope/name 文件）
```

## workspace 依赖处理（发布时替换为 semver）

- `workspace:*` → 读取 node_modules 下依赖包实际版本，替换为精确版本（如 `0.61.0`）
- `workspace:<version>` → 替换为精确版本
- `workspace:^<version>` / `workspace:~<version>` → 保留范围前缀（如 `^0.61.0`）
- 其余非法范围 → 报错

依赖必须以 semver 形式发布（不能是 URL：pnpm 11 `blockExoticSubdeps` 禁止发布包的子依赖为 URL 形式），消费方项目通过 `.npmrc` 的 `@pipers:registry` 指向静态 registry 解析。

## 开发

```bash
pnpm run build    # rm -rf dist && tsc && tsc-alias
pnpm run test     # tsx --test（41 tests）
pnpm run lint     # eslint src
```

## 测试

- 单元：semver 解析/比较/latest、metadata 组装、integrity、tgz 读取（标准 `package/` 前缀 + 旧无前缀兼容）
- 集成：打包（tar 产物校验、workspace 替换）、上传（Git 数据 API 调用顺序/参数 mock 断言）
