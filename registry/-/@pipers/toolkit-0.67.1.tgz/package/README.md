# @pipers/toolkit

与 Pipers 框架语义无关的通用 TypeScript 工具库：store、emitter、stream、json、yaml、bon、schema、json-web-token、scheduler、id、encoding、cache、iterator 等。

## 安装

```bash
pnpm add @pipers/toolkit
```

## 导入

**必须从子路径按需导入**——本包没有根导出，`import … from '@pipers/toolkit'` 会直接抛错：

```ts
import { createMemoryCache } from '@pipers/toolkit/cache';
import { Schema } from '@pipers/toolkit/schema';
import { JSON } from '@pipers/toolkit/json';
```

平台相关能力集中在 `@pipers/toolkit/node/*`（`environment` · `filesystem` · `globby` · `shell` · `stream` · `workspace`）；**其余子路径不含平台依赖**，可用于浏览器。完整子路径清单见包内 `package.json` 的 `exports` 字段。

## 文档与变更

- 使用指南：https://github.com/DevinDon/pipers/blob/main/docs/README.md
- 变更记录（含破坏性变更与迁移对照）：https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md

## 许可

MIT © IInfinity
