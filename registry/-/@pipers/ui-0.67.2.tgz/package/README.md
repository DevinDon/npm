# @pipers/ui

Pipers 自有 UI 组件库：shadcn/ui 风格，Tailwind v4 + Base UI（base-nova 基座）。

## 两个反常规的设计

- **JS 预编译、CSS 不预编译**：组件样式由**消费端**用 Tailwind v4 的 `@source` 扫描本包源码后本地生成——因此发布物里包含 `src`（编译期需要）。
- **组件即源码参照物**：每个组件是一个独立模块目录（`src/components/<name>/`），可读、可改、可裁剪。

## 安装

```bash
pnpm add @pipers/ui
pnpm add -D tailwindcss @tailwindcss/vite
```

React 与 recharts 为 peer 依赖，需由应用自行安装（版本要求见包内 `package.json` 的 `peerDependencies`）。

## 消费端配置

在应用的 CSS 入口中（`@import "tailwindcss"` 之后）：

```css
@import "@pipers/ui/theme.css";
@source "../node_modules/@pipers/ui";
```

`@source` 指向本包源码——缺少它时组件类名不会被生成（Tailwind v4 默认只扫描应用自己的 cwd）。

## 使用

```tsx
import { Button } from '@pipers/ui';
```

## 文档与变更

- 消费端组件用法见仓库内 `frontend-guideline` skill 的 `references/pipers-ui-guide.md`
- 使用指南：https://github.com/DevinDon/pipers/blob/main/docs/README.md
- 变更记录（含破坏性变更与迁移对照）：https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md

## 许可

MIT © IInfinity
