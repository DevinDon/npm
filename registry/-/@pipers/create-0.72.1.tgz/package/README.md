# @pipers/create

`create-pipers` 脚手架：创建 Pipers 工作区、应用或模块。

## 使用

```bash
# 创建工作区（项目）
pnpm create @pipers

# 或直接调用
npx create-pipers@latest
```

CLI 子命令：`project`（别名 `p`，创建工作区）· `application`（别名 `a`，创建应用）· `sync`（别名 `s`，同步技能模板到已有项目）。

## 说明

- 模板由仓库中的示例应用生成（包内 `templates/` 为生成物，勿手改——改模板要改源）。
- 模板不预置项目文档与工作流 skill：`documents/` 与 `iteration-workflow` 一类通用指导由新工作区自行用 `iteration-workflow-setup` 装配；随模板只下发 `pipers-usage-guideline`（Pipers 应用开发指导）。
- 前后端成对创建时，后端应用名取「前端应用名 + `-api`」（如前端 `console` ↔ 后端 `console-api`）：模板按此后缀渲染前端对后端契约包的依赖。
- 生成的应用可直接 `pnpm install` 后运行；需要 Node.js 与 pnpm。

## 同步技能

把包内已渲染好的模板资源渲染后写入已有项目：技能模板（`templates/project/.agents/skills/`）写入项目 `.agents/skills/`，其它文件与章节不动：

```bash
# 同步到指定目录，或不传目录时用当前目录
pnpm create @pipers sync [directory]

# 试运行：列出待新增 / 更新的目标与三类计数，不写入也不备份
pnpm create @pipers sync --dry-run
```

- 目标必须是 Pipers 项目（含 `package.json` 且依赖里有 `@pipers/*`）；项目名取自 `package.json` 的 `name`，应用名从 `packages/*/package.json` 的包名（`@<项目>/<应用>[-api]`）推导。
- 多应用项目默认取排序后的第一个应用渲染，并在输出中列出全部候选；可用 `-a, --application <name>` 显式指定。
- 写入前先与目标文件比对，按 `新增` / `更新` / `未变化` 分类并收尾输出三类计数；`未变化` 不写入也不备份。
- 默认覆盖前把内容有变化的同名文件备份到项目根下的 `temp/skills-backup-<时间戳>/`（`temp/` 已在项目 `.gitignore` 中），输出会告知备份位置。
- 未生成 `templates/` 时会提示先在仓库根执行 `pnpm action template`。

## 文档与变更

- 使用指南：<https://github.com/DevinDon/pipers/blob/main/documents/pipers/repository/README.md>
- 变更记录（含破坏性变更与迁移对照）：<https://github.com/DevinDon/pipers/blob/main/documents/pipers/repository/CHANGELOG.md>

## 许可

MIT © IInfinity
