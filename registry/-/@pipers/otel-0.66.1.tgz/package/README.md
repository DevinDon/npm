# @pipers/otel

Pipers 框架的 OpenTelemetry 集成包——为 Pipers 管道提供标准可观测性（W3C Trace Context + OTel 语义），仅依赖轻量的 `@opentelemetry/api`（~10KB 零依赖）。

## 子路径导出（按环境拆分）

| 子路径 | 适用 | 内容 |
|--------|------|------|
| `@pipers/otel`（顶层） | 服务端（兼容） | `useOpenTelemetry` / `withSpan` |
| `@pipers/otel/node` | 服务端（显式） | 同上（`node/` 子目录） |
| `@pipers/otel/web` | 浏览器端 | `useWebOpenTelemetry` / `generateTraceParent` 等 |

## 特性

- **根 span**：HTTP 请求级 `http.server.request` span（OTel 语义约定属性：`http.request.method` / `url.path` / `server.address` / `http.response.status_code`），由传输层（h1/h2）在 context 创建与 finish 时触发
- **入站 traceparent 继承**：请求携带 W3C traceparent 头时，根 span 继承入站 trace-id 并以入站 span-id 为父（外部系统链路贯通）；无/非法头则生成新链路
- **子 span**：管道函数级 span（配合 `@pipers/core` 的 `viaObserving` 装饰器），span 栈维护父子关系，嵌套 `viaObserving` 天然成树
- **手动 span**：`withSpan` 包裹无 HTTP context 的独立执行单元（如定时任务）
- **浏览器导航根 span**：`useWebOpenTelemetry`（`@pipers/otel/web`）管理页面加载/路由切换根 span，前端请求归属当前导航（每次导航 = 新 trace）
- **零开销**：无观测器时管道走原始路径；未安装 SDK 时 NoopTracer 全 no-op，不抛错

## 服务端使用（`@pipers/otel` / `@pipers/otel/node`）

```ts
import { useOpenTelemetry, withSpan } from '@pipers/otel';
import { viaObserving } from '@pipers/core';
import { createNodeH1Pipers } from '@pipers/core/http/h1-node';
import { Pipers } from '@pipers/core';

// 1. 创建观测器（一行接入）
const observer = useOpenTelemetry({ serviceName: 'my-service' });

// 2. 传输层启用（根 span + 入站 traceparent 继承）
await createNodeH1Pipers({ server, listening, observer });

// 3. 业务管道内装饰子 span（name 用 kebab-case 业务语义名，便于识别）
Pipers.pipe(
  viaObserving({
    name: 'list-events',
    pipeline: async (context, query) => listEvents(query),
  }),
  viaJSONEncoder({ schema: ToClientSchema }),
);

// 4. 无 context 场景（定时任务）用手动 span
await withSpan({ name: 'sync-stars' }, () => syncStars());
```

## 浏览器端使用（`@pipers/otel/web`）

```ts
import { WebTracerProvider } from '@opentelemetry/sdk-trace-web';  // 使用方自装
import { ZoneContextManager } from '@opentelemetry/context-zone';
import { useWebOpenTelemetry } from '@pipers/otel/web';

// 1. SDK 注册（使用方安装；依赖倒置：SDK 实例由使用方传入）
const provider = new WebTracerProvider({ spanProcessors: [...] });
provider.register({ contextManager: new ZoneContextManager() });

// 2. 创建控制器（导航根 span 管理）
const { onNavigate, getTraceParent } = useWebOpenTelemetry({
  provider,
  serviceName: 'my-web-app',
});

// 3. 页面加载 / 路由切换时调用（每次导航 = 新 trace）
onNavigate();

// 4. 请求时生成 traceparent（归属当前导航；实际项目可在 fetch 封装中统一注入，如 conductor 的 foundations/functions/request-json.mts）
fetch('/api/x', { headers: { traceparent: getTraceParent() } });
```

## 导出 SDK

SDK 由使用方自行安装（服务端 `@opentelemetry/sdk-trace-node`、浏览器 `@opentelemetry/sdk-trace-web`）并注册全局 TracerProvider；未注册时本包全 no-op。三层解耦：core 观测钩子（零依赖）→ 本包（仅 API 层）→ 用户 SDK。

参考接入示例：

- 服务端：`applications/conductor-api`（`src/foundations/integrations/otel.mts` 按环境配置 SDK + `main.mts` 启动时初始化）
- 浏览器：`applications/conductor`（`src/foundations/tracing/use-web-tracing.mts` 注册 SDK + `root.tsx` 路由监听 onNavigate）

## 文档 / Docs

另见 [Pipers 使用文档](../../docs/README.md)。

## 开源许可 / License

[THE MIT LICENSE](https://raw.githubusercontent.com/DevinDon/license/master/THE%20MIT%20LICENSE) for code.

Copyright IInfinity © 2018+
