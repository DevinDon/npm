# @pipers/create

`create-pipers` 脚手架：创建 Pipers 工作区、应用或模块。

## 使用

```bash
# 创建工作区（项目）
pnpm create pipers

# 或直接调用
npx create-pipers@latest
```

CLI 子命令：`project`（别名 `p`，创建工作区）· `application`（别名 `a`，创建应用）· `sync`（别名 `s`，同步技能与根 `AGENTS.md` 的 Skills 表）。

## 说明

- 模板由仓库中的示例应用生成（包内 `templates/` 为生成物，勿手改——改模板要改源）。
- 前后端成对创建时，后端应用名取「前端应用名 + `-api`」（如前端 `console` ↔ 后端 `console-api`）：模板按此后缀渲染前端对后端契约包的依赖。
- 生成的应用可直接 `pnpm install` 后运行；需要 Node.js 与 pnpm。

## 同步技能与 AGENTS.md

把包内已渲染好的模板资源渲染后写入已有项目：技能模板（`templates/project/.agents/skills/`）写入项目 `.agents/skills/`，项目根 `AGENTS.md` 只替换标记区块内的 Skills 表，其余文件与章节不动：

```bash
# 同步到指定目录，或不传目录时用当前目录
pnpm create @pipers sync [directory]

# 试运行：列出待新增 / 更新的目标与三类计数，不写入也不备份
pnpm create @pipers sync --dry-run

# 目标根 AGENTS.md 缺标记对时，按 Skills 表启发式注入标记后再替换
pnpm create @pipers sync --init-agents
```

- 目标必须是 Pipers 项目（含 `package.json` 且依赖里有 `@pipers/*`）；项目名取自 `package.json` 的 `name`，应用名从 `packages/*/package.json` 的包名（`@<项目>/<应用>[-api]`）推导。
- 多应用项目默认取排序后的第一个应用渲染，并在输出中列出全部候选；可用 `-a, --application <name>` 显式指定。
- 写入前先与目标文件比对，按 `新增` / `更新` / `未变化` 分类并收尾输出三类计数；`未变化` 不写入也不备份。
- 根 `AGENTS.md` 的同步范围限于 `<!-- create-pipers:agents-skills:begin -->` 与 `<!-- create-pipers:agents-skills:end -->` 之间（标记为 HTML 注释，Markdown 渲染不可见）；目标缺标记对时跳过并 `warn`，不整文件覆盖。
- `--init-agents`：目标根 `AGENTS.md` 无标记对时，定位 `## <数字>. Skills` 标题后的连续表格行，用标记对包裹（不改表内容）后再作区块替换；定位不到表则报错退出。
- 默认覆盖前把内容有变化的同名文件备份到项目根下的 `temp/skills-backup-<时间戳>/`（`temp/` 已在项目 `.gitignore` 中，根 `AGENTS.md` 一并备份），输出会告知备份位置。
- 未生成 `templates/` 时会提示先在仓库根执行 `pnpm action template`。

## 文档与变更

- 使用指南：<https://github.com/DevinDon/pipers/blob/main/docs/README.md>
- 变更记录（含破坏性变更与迁移对照）：<https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md>

## 许可

MIT © IInfinity
