# @pipers/create

`create-pipers` 脚手架：创建 Pipers 工作区、应用或模块。

## 使用

```bash
# 创建工作区（项目）
pnpm create pipers

# 或直接调用
npx create-pipers@latest
```

CLI 子命令：`project`（别名 `p`，创建工作区）· `application`（别名 `a`，创建应用）。

## 说明

- 模板由仓库中的示例应用生成（包内 `templates/` 为生成物，勿手改——改模板要改源）。
- 生成的应用可直接 `pnpm install` 后运行；需要 Node.js 与 pnpm。

## 文档与变更

- 使用指南：https://github.com/DevinDon/pipers/blob/main/docs/README.md
- 变更记录（含破坏性变更与迁移对照）：https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md

## 许可

MIT © IInfinity
