import { type ComponentProps } from 'react';
import { cn } from '@/lib/utils.mjs';

export const MessageGroup = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='message-group'
    className={ cn('flex min-w-0 flex-col gap-2', className) }
    { ...props }
  />
);

export const Message = ({
  className,
  align = 'start',
  ...props
}: ComponentProps<'div'> & { align?: 'start' | 'end' }) => (
  <div
    data-slot='message'
    data-align={ align }
    className={ cn(
      'group/message relative flex w-full min-w-0 gap-2 text-sm data-[align=end]:flex-row-reverse',
      className,
    ) }
    { ...props }
  />
);

export const MessageAvatar = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='message-avatar'
    className={ cn(
      'flex w-fit min-w-8 shrink-0 items-center justify-center self-end overflow-hidden rounded-full bg-muted group-has-data-[slot=message-footer]/message:-translate-y-8',
      className,
    ) }
    { ...props }
  />
);

export const MessageContent = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='message-content'
    className={ cn(
      'flex w-full min-w-0 flex-col gap-2.5 wrap-break-word group-data-[align=end]/message:*:data-slot:self-end',
      className,
    ) }
    { ...props }
  />
);

export const MessageHeader = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='message-header'
    className={ cn(
      'flex max-w-full min-w-0 items-center px-3 text-xs font-medium text-muted-foreground group-has-data-[variant=ghost]/message:px-0',
      className,
    ) }
    { ...props }
  />
);

export const MessageFooter = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='message-footer'
    className={ cn(
      'flex max-w-full min-w-0 items-center px-3 text-xs font-medium text-muted-foreground group-has-data-[variant=ghost]/message:px-0 group-data-[align=end]/message:justify-end',
      className,
    ) }
    { ...props }
  />
);

