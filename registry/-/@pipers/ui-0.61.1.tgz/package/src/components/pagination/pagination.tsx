import { type ComponentProps } from 'react';
import { cn } from '@/lib/utils.mjs';
import { Button } from '@/components/button/index.mjs';
import { ChevronLeftIcon, ChevronRightIcon, MoreHorizontalIcon } from 'lucide-react';

export const Pagination = ({ className, ...props }: ComponentProps<'nav'>) => (
  <nav
    role='navigation'
    aria-label='pagination'
    data-slot='pagination'
    className={ cn('mx-auto flex w-full justify-center', className) }
    { ...props }
  />
);

export const PaginationContent = ({
  className,
  ...props
}: ComponentProps<'ul'>) => (
  <ul
    data-slot='pagination-content'
    className={ cn('flex items-center gap-0.5', className) }
    { ...props }
  />
);

export const PaginationItem = ({ ...props }: ComponentProps<'li'>) => <li data-slot='pagination-item' { ...props } />;

type PaginationLinkProps = {
  isActive?: boolean;
} & Pick<ComponentProps<typeof Button>, 'size'>
  & ComponentProps<'a'>;

export const PaginationLink = ({
  className,
  isActive,
  size = 'icon',
  ...props
}: PaginationLinkProps) => (
  <Button
    variant={ isActive ? 'outline' : 'ghost' }
    size={ size }
    className={ cn(className) }
    nativeButton={ false }
    render={
      (<a
        aria-current={ isActive ? 'page' : undefined }
        data-slot='pagination-link'
        data-active={ isActive }
        { ...props }
      />)
    }
  />
);

export const PaginationPrevious = ({
  className,
  text = 'Previous',
  ...props
}: ComponentProps<typeof PaginationLink> & { text?: string }) => (
  <PaginationLink
    aria-label='Go to previous page'
    size='default'
    className={ cn('pl-1.5!', className) }
    { ...props }
  >
    <ChevronLeftIcon data-icon='inline-start' />
    <span className='hidden sm:block'>{ text }</span>
  </PaginationLink>
);

export const PaginationNext = ({
  className,
  text = 'Next',
  ...props
}: ComponentProps<typeof PaginationLink> & { text?: string }) => (
  <PaginationLink
    aria-label='Go to next page'
    size='default'
    className={ cn('pr-1.5!', className) }
    { ...props }
  >
    <span className='hidden sm:block'>{ text }</span>
    <ChevronRightIcon data-icon='inline-end' />
  </PaginationLink>
);

export const PaginationEllipsis = ({
  className,
  ...props
}: ComponentProps<'span'>) => (
  <span
    aria-hidden
    data-slot='pagination-ellipsis'
    className={ cn(
      "flex size-8 items-center justify-center [&_svg:not([class*='size-'])]:size-4",
      className,
    ) }
    { ...props }
  >
    <MoreHorizontalIcon />
    <span className='sr-only'>More pages</span>
  </span>
);

