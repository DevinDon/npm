import { type ComponentProps } from 'react';
import { cn } from '@/lib/utils.mjs';
import { Loader2Icon } from 'lucide-react';

export const Spinner = ({ className, ...props }: ComponentProps<typeof Loader2Icon>) => (
  <Loader2Icon data-slot='spinner' role='status' aria-label='Loading' className={ cn('size-4 animate-spin', className) } { ...props } />
);

