import { cn } from '@/lib/utils.mjs';
import { type ComponentProps } from 'react';

export const Skeleton = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='skeleton'
    className={ cn('animate-pulse rounded-md bg-muted', className) }
    { ...props }
  />
);

