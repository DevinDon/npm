import { Accordion as AccordionPrimitive } from '@base-ui/react/accordion';

import { cn } from '@/lib/utils.mjs';
import { ChevronDownIcon } from 'lucide-react';

export const Accordion = ({ className, ...props }: AccordionPrimitive.Root.Props) => (
  <AccordionPrimitive.Root
    data-slot='accordion'
    className={ cn('flex w-full flex-col', className) }
    { ...props }
  />
);

export const AccordionItem = ({ className, ...props }: AccordionPrimitive.Item.Props) => (
  <AccordionPrimitive.Item
    data-slot='accordion-item'
    className={ cn('not-last:border-b not-last:border-border', className) }
    { ...props }
  />
);

export const AccordionTrigger = ({
  className,
  children,
  ...props
}: AccordionPrimitive.Trigger.Props) => (
  <AccordionPrimitive.Header className='flex'>
    <AccordionPrimitive.Trigger
      data-slot='accordion-trigger'
      className={ cn(
        'group/accordion-trigger relative flex flex-1 items-start justify-between rounded-lg border border-transparent py-3 text-left text-sm font-medium transition-all outline-none group-hover/accordion-trigger:**:data-[slot=accordion-trigger-icon]:text-foreground focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:after:border-ring aria-disabled:pointer-events-none aria-disabled:opacity-50 **:data-[slot=accordion-trigger-icon]:ml-auto **:data-[slot=accordion-trigger-icon]:size-4 **:data-[slot=accordion-trigger-icon]:text-muted-foreground',
        className,
      ) }
      { ...props }
    >
      { children }
      <ChevronDownIcon data-slot='accordion-trigger-icon' className='pointer-events-none shrink-0 transition-transform duration-200 group-aria-expanded/accordion-trigger:rotate-180' />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
);

export const AccordionContent = ({
  className,
  children,
  ...props
}: AccordionPrimitive.Panel.Props) => (
  <AccordionPrimitive.Panel
    data-slot='accordion-content'
    className='overflow-hidden text-sm data-open:animate-accordion-down data-closed:animate-accordion-up'
    { ...props }
  >
    <div
      className={ cn(
        'h-(--accordion-panel-height) pt-0 pb-3 data-starting-style:h-0 data-ending-style:h-0 data-open:animate-accordion-content-in [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground [&_p:not(:last-child)]:mb-4',
        className,
      ) }
    >
      { children }
    </div>
  </AccordionPrimitive.Panel>
);
