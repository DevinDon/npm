import { cva, type VariantProps } from 'class-variance-authority';
import { type ComponentProps } from 'react';

import { cn } from '@/lib/utils.mjs';

export const Empty = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='empty'
    className={ cn(
      'flex w-full min-w-0 flex-1 flex-col items-center justify-center gap-4 rounded-xl border-dashed p-6 text-center text-balance',
      className,
    ) }
    { ...props }
  />
);

export const EmptyHeader = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='empty-header'
    className={ cn('flex max-w-sm flex-col items-center gap-2', className) }
    { ...props }
  />
);

const emptyMediaVariants = cva(
  'mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0',
  {
    variants: {
      variant: {
        default: 'bg-transparent',
        icon: "flex size-8 shrink-0 items-center justify-center rounded-lg bg-muted text-foreground [&_svg:not([class*='size-'])]:size-4",
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

export const EmptyMedia = ({
  className,
  variant = 'default',
  ...props
}: ComponentProps<'div'> & VariantProps<typeof emptyMediaVariants>) => (
  <div
    data-slot='empty-icon'
    data-variant={ variant }
    className={ cn(emptyMediaVariants({ variant, className })) }
    { ...props }
  />
);

export const EmptyTitle = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='empty-title'
    className={ cn(
      'font-heading text-sm font-medium tracking-tight',
      className,
    ) }
    { ...props }
  />
);

export const EmptyDescription = ({ className, ...props }: ComponentProps<'p'>) => (
  <div
    data-slot='empty-description'
    className={ cn(
      'text-sm/relaxed text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary',
      className,
    ) }
    { ...props }
  />
);

export const EmptyContent = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='empty-content'
    className={ cn(
      'flex w-full max-w-sm min-w-0 flex-col items-center gap-2.5 text-sm text-balance',
      className,
    ) }
    { ...props }
  />
);

