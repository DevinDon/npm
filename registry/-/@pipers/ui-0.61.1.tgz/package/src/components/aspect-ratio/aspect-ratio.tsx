import { type ComponentProps, type CSSProperties } from 'react';
import { cn } from '@/lib/utils.mjs';

export const AspectRatio = ({
  ratio,
  className,
  ...props
}: ComponentProps<'div'> & { ratio: number }) => (
  <div
    data-slot='aspect-ratio'
    style={
      {
        '--ratio': ratio,
      } as CSSProperties
    }
    className={ cn('relative aspect-(--ratio)', className) }
    { ...props }
  />
);
