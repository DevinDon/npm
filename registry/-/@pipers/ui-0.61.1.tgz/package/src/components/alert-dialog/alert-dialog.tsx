'use client';

import { type ComponentProps } from 'react';
import { AlertDialog as AlertDialogPrimitive } from '@base-ui/react/alert-dialog';

import { cn } from '@/lib/utils.mjs';
import { Button } from '@/components/button/index.mjs';

export const AlertDialog = ({ ...props }: AlertDialogPrimitive.Root.Props) => <AlertDialogPrimitive.Root data-slot='alert-dialog' { ...props } />;

export const AlertDialogTrigger = ({ ...props }: AlertDialogPrimitive.Trigger.Props) => (
  <AlertDialogPrimitive.Trigger data-slot='alert-dialog-trigger' { ...props } />
);

export const AlertDialogPortal = ({ ...props }: AlertDialogPrimitive.Portal.Props) => (
  <AlertDialogPrimitive.Portal data-slot='alert-dialog-portal' { ...props } />
);

export const AlertDialogOverlay = ({
  className,
  ...props
}: AlertDialogPrimitive.Backdrop.Props) => (
  <AlertDialogPrimitive.Backdrop
    data-slot='alert-dialog-overlay'
    className={ cn(
      'fixed inset-0 isolate z-50 bg-black/10 duration-150 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0',
      className,
    ) }
    { ...props }
  />
);

export const AlertDialogContent = ({
  className,
  size = 'default',
  ...props
}: AlertDialogPrimitive.Popup.Props & {
  size?: 'default' | 'sm';
}) => (
  <AlertDialogPortal>
    <AlertDialogOverlay />
    <AlertDialogPrimitive.Popup
      data-slot='alert-dialog-content'
      data-size={ size }
      className={ cn(
        'group/alert-dialog-content fixed top-1/2 left-1/2 z-50 grid w-full -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-popover p-4 text-popover-foreground ring-1 ring-foreground/10 duration-150 outline-none data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95',
        className,
      ) }
      { ...props }
    />
  </AlertDialogPortal>
);

export const AlertDialogHeader = ({
  className,
  ...props
}: ComponentProps<'div'>) => (
  <div
    data-slot='alert-dialog-header'
    className={ cn(
      'grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-4 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-left sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]',
      className,
    ) }
    { ...props }
  />
);

export const AlertDialogFooter = ({
  className,
  ...props
}: ComponentProps<'div'>) => (
  <div
    data-slot='alert-dialog-footer'
    className={ cn(
      '-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t border-t-border bg-muted/50 p-4 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end',
      className,
    ) }
    { ...props }
  />
);

export const AlertDialogMedia = ({
  className,
  ...props
}: ComponentProps<'div'>) => (
  <div
    data-slot='alert-dialog-media'
    className={ cn(
      "mb-2 inline-flex size-10 items-center justify-center rounded-md bg-muted sm:group-data-[size=default]/alert-dialog-content:row-span-2 *:[svg:not([class*='size-'])]:size-6",
      className,
    ) }
    { ...props }
  />
);

export const AlertDialogTitle = ({
  className,
  ...props
}: ComponentProps<typeof AlertDialogPrimitive.Title>) => (
  <AlertDialogPrimitive.Title
    data-slot='alert-dialog-title'
    className={ cn(
      'font-heading text-base font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2',
      className,
    ) }
    { ...props }
  />
);

export const AlertDialogDescription = ({
  className,
  ...props
}: ComponentProps<typeof AlertDialogPrimitive.Description>) => (
  <AlertDialogPrimitive.Description
    data-slot='alert-dialog-description'
    className={ cn(
      'text-sm text-balance text-muted-foreground md:text-pretty *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground',
      className,
    ) }
    { ...props }
  />
);

export const AlertDialogAction = ({
  className,
  ...props
}: ComponentProps<typeof Button>) => (
  <Button
    data-slot='alert-dialog-action'
    className={ cn(className) }
    { ...props }
  />
);

export const AlertDialogCancel = ({
  className,
  variant = 'outline',
  size = 'default',
  ...props
}: AlertDialogPrimitive.Close.Props
  & Pick<ComponentProps<typeof Button>, 'variant' | 'size'>) => (
  <AlertDialogPrimitive.Close
    data-slot='alert-dialog-cancel'
    className={ cn(className) }
    render={ <Button variant={ variant } size={ size } /> }
    { ...props }
  />
);
