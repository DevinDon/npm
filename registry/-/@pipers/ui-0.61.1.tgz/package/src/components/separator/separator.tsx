'use client';

import { Separator as SeparatorPrimitive } from '@base-ui/react/separator';

import { cn } from '@/lib/utils.mjs';

export const Separator = ({
  className,
  orientation = 'horizontal',
  ...props
}: SeparatorPrimitive.Props) => (
  <SeparatorPrimitive
    data-slot='separator'
    orientation={ orientation }
    className={ cn(
      'shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch',
      className,
    ) }
    { ...props }
  />
);

