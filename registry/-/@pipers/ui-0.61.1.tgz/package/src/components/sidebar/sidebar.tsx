import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { type CSSProperties, type ComponentProps } from 'react';
import { mergeProps } from '@base-ui/react/merge-props';
import { useRender } from '@base-ui/react/use-render';
import { cva, type VariantProps } from 'class-variance-authority';

import { useIsMobile } from '@/hooks/use-mobile/index.mjs';
import { cn } from '@/lib/utils.mjs';
import { Button } from '@/components/button/index.mjs';
import { Input } from '@/components/input/index.mjs';
import { Separator } from '@/components/separator/index.mjs';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from '@/components/sheet/index.mjs';
import { Skeleton } from '@/components/skeleton/index.mjs';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from '@/components/tooltip/index.mjs';
import { PanelLeftIcon } from 'lucide-react';

const SIDEBAR_COOKIE_NAME = 'sidebar_state';
const SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
const SIDEBAR_WIDTH = '16rem';
const SIDEBAR_WIDTH_MOBILE = '18rem';
const SIDEBAR_WIDTH_ICON = '3rem';
const SIDEBAR_KEYBOARD_SHORTCUT = 'b';

type SidebarContextProps = {
  state: 'expanded' | 'collapsed';
  open: boolean;
  setOpen: (open: boolean) => void;
  openMobile: boolean;
  setOpenMobile: (open: boolean) => void;
  isMobile: boolean;
  toggleSidebar: () => void;
};

const SidebarContext = createContext<SidebarContextProps | null>(null);

export const useSidebar = () => {
  const context = useContext(SidebarContext);
  if (!context) {
    throw new Error('useSidebar must be used within a SidebarProvider.');
  }

  return context;
};

export const SidebarProvider = ({
  defaultOpen = true,
  open: openProp,
  onOpenChange: setOpenProp,
  className,
  style,
  children,
  ...props
}: ComponentProps<'div'> & {
  defaultOpen?: boolean;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}) => {
  const isMobile = useIsMobile();
  const [ openMobile, setOpenMobile ] = useState(false);

  // This is the internal state of the sidebar.
  // We use openProp and setOpenProp for control from outside the component.
  const [ openState, setOpenState ] = useState(defaultOpen);
  const open = openProp ?? openState;
  const setOpen = useCallback(
    (value: boolean | ((value: boolean) => boolean)) => {
      const openState = typeof value === 'function' ? value(open) : value;
      if (setOpenProp) {
        setOpenProp(openState);
      } else {
        setOpenState(openState);
      }

      // This sets the cookie to keep the sidebar state.
      document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
    },
    [ setOpenProp, open ],
  );

  // Helper to toggle the sidebar.
  const toggleSidebar = useCallback(() => (isMobile ? setOpenMobile(open => !open) : setOpen(open => !open)), [ isMobile, setOpen, setOpenMobile ]);

  // Adds a keyboard shortcut to toggle the sidebar.
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (
        event.key === SIDEBAR_KEYBOARD_SHORTCUT
        && (event.metaKey || event.ctrlKey)
      ) {
        event.preventDefault();
        toggleSidebar();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [ toggleSidebar ]);

  // We add a state so that we can do data-state="expanded" or "collapsed".
  // This makes it easier to style the sidebar with Tailwind classes.
  const state = open ? 'expanded' : 'collapsed';

  const contextValue = useMemo<SidebarContextProps>(
    () => ({
      state,
      open,
      setOpen,
      isMobile,
      openMobile,
      setOpenMobile,
      toggleSidebar,
    }),
    [ state, open, setOpen, isMobile, openMobile, setOpenMobile, toggleSidebar ],
  );

  return (
    <SidebarContext.Provider value={ contextValue }>
      <div
        data-slot='sidebar-wrapper'
        style={
          {
            '--sidebar-width': SIDEBAR_WIDTH,
            '--sidebar-width-icon': SIDEBAR_WIDTH_ICON,
            ...style,
          } as CSSProperties
        }
        className={ cn(
          'group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar',
          className,
        ) }
        { ...props }
      >
        { children }
      </div>
    </SidebarContext.Provider>
  );
};

export const Sidebar = ({
  side = 'left',
  variant = 'sidebar',
  collapsible = 'offcanvas',
  className,
  children,
  dir,
  ...props
}: ComponentProps<'div'> & {
  side?: 'left' | 'right';
  variant?: 'sidebar' | 'floating' | 'inset';
  collapsible?: 'offcanvas' | 'icon' | 'none';
}) => {
  const { isMobile, state, openMobile, setOpenMobile } = useSidebar();

  if (collapsible === 'none') {
    return (
      <div
        data-slot='sidebar'
        className={ cn(
          'flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground',
          className,
        ) }
        { ...props }
      >
        { children }
      </div>
    );
  }

  if (isMobile) {
    return (
      <Sheet open={ openMobile } onOpenChange={ setOpenMobile } { ...props }>
        <SheetContent
          dir={ dir }
          data-sidebar='sidebar'
          data-slot='sidebar'
          data-mobile='true'
          className='w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden'
          style={
            {
              '--sidebar-width': SIDEBAR_WIDTH_MOBILE,
            } as CSSProperties
          }
          side={ side }
        >
          <SheetHeader className='sr-only'>
            <SheetTitle>Sidebar</SheetTitle>
            <SheetDescription>Displays the mobile sidebar.</SheetDescription>
          </SheetHeader>
          <div className='flex h-full w-full flex-col'>{ children }</div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <div
      className='group peer hidden text-sidebar-foreground md:block'
      data-state={ state }
      data-collapsible={ state === 'collapsed' ? collapsible : '' }
      data-variant={ variant }
      data-side={ side }
      data-slot='sidebar'
    >
      { /* This is what handles the sidebar gap on desktop */ }
      <div
        data-slot='sidebar-gap'
        className={ cn(
          'relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear',
          'group-data-[collapsible=offcanvas]:w-0',
          'group-data-[side=right]:rotate-180',
          variant === 'floating' || variant === 'inset'
            ? 'group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]'
            : 'group-data-[collapsible=icon]:w-(--sidebar-width-icon)',
        ) }
      />
      <div
        data-slot='sidebar-container'
        data-side={ side }
        className={ cn(
          'fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)] md:flex',
          // Adjust the padding for floating and inset variants.
          variant === 'floating' || variant === 'inset'
            ? 'p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]'
            : 'group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=left]:border-border group-data-[side=right]:border-l group-data-[side=right]:border-border',
          className,
        ) }
        { ...props }
      >
        <div
          data-sidebar='sidebar'
          data-slot='sidebar-inner'
          className='flex size-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:shadow-sm group-data-[variant=floating]:ring-1 group-data-[variant=floating]:ring-sidebar-border'
        >
          { children }
        </div>
      </div>
    </div>
  );
};

export const SidebarTrigger = ({
  className,
  onClick,
  ...props
}: ComponentProps<typeof Button>) => {
  const { toggleSidebar } = useSidebar();

  return (
    <Button
      data-sidebar='trigger'
      data-slot='sidebar-trigger'
      variant='ghost'
      size='icon-sm'
      className={ cn(className) }
      onClick={ event => {
        onClick?.(event);
        toggleSidebar();
      } }
      { ...props }
    >
      <PanelLeftIcon />
      <span className='sr-only'>Toggle Sidebar</span>
    </Button>
  );
};

export const SidebarRail = ({ className, ...props }: ComponentProps<'button'>) => {
  const { toggleSidebar } = useSidebar();

  return (
    <button
      data-sidebar='rail'
      data-slot='sidebar-rail'
      aria-label='Toggle Sidebar'
      tabIndex={ -1 }
      onClick={ toggleSidebar }
      title='Toggle Sidebar'
      className={ cn(
        'absolute inset-y-0 z-20 hidden w-4 transition-all ease-linear group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:start-1/2 after:w-[2px] hover:after:bg-sidebar-border sm:flex ltr:-translate-x-1/2 rtl:-translate-x-1/2',
        'in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize',
        '[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize',
        'group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full hover:group-data-[collapsible=offcanvas]:bg-sidebar',
        '[[data-side=left][data-collapsible=offcanvas]_&]:-right-2',
        '[[data-side=right][data-collapsible=offcanvas]_&]:-left-2',
        className,
      ) }
      { ...props }
    />
  );
};

export const SidebarInset = ({ className, ...props }: ComponentProps<'main'>) => (
  <main
    data-slot='sidebar-inset'
    className={ cn(
      'relative flex w-full flex-1 flex-col bg-background md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2',
      className,
    ) }
    { ...props }
  />
);

export const SidebarInput = ({
  className,
  ...props
}: ComponentProps<typeof Input>) => (
  <Input
    data-slot='sidebar-input'
    data-sidebar='input'
    className={ cn('h-8 w-full bg-background shadow-none', className) }
    { ...props }
  />
);

export const SidebarHeader = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='sidebar-header'
    data-sidebar='header'
    className={ cn('flex flex-col gap-2 p-2', className) }
    { ...props }
  />
);

export const SidebarFooter = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='sidebar-footer'
    data-sidebar='footer'
    className={ cn('flex flex-col gap-2 p-2', className) }
    { ...props }
  />
);

export const SidebarSeparator = ({
  className,
  ...props
}: ComponentProps<typeof Separator>) => (
  <Separator
    data-slot='sidebar-separator'
    data-sidebar='separator'
    className={ cn('mx-2 w-auto bg-sidebar-border', className) }
    { ...props }
  />
);

export const SidebarContent = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='sidebar-content'
    data-sidebar='content'
    className={ cn(
      'no-scrollbar flex min-h-0 flex-1 flex-col gap-0 overflow-auto group-data-[collapsible=icon]:overflow-hidden',
      className,
    ) }
    { ...props }
  />
);

export const SidebarGroup = ({ className, ...props }: ComponentProps<'div'>) => (
  <div
    data-slot='sidebar-group'
    data-sidebar='group'
    className={ cn('relative flex w-full min-w-0 flex-col p-2', className) }
    { ...props }
  />
);

export const SidebarGroupLabel = ({
  className,
  render,
  ...props
}: useRender.ComponentProps<'div'> & ComponentProps<'div'>) => useRender({
  defaultTagName: 'div',
  props: mergeProps<'div'>(
    {
      className: cn(
        'flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-200 ease-linear group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0 focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0',
        className,
      ),
    },
    props,
  ),
  render,
  state: {
    slot: 'sidebar-group-label',
    sidebar: 'group-label',
  },
});

export const SidebarGroupAction = ({
  className,
  render,
  ...props
}: useRender.ComponentProps<'button'> & ComponentProps<'button'>) => useRender({
  defaultTagName: 'button',
  props: mergeProps<'button'>(
    {
      className: cn(
        'absolute top-3.5 right-3 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground ring-sidebar-ring outline-hidden transition-transform group-data-[collapsible=icon]:hidden after:absolute after:-inset-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 md:after:hidden [&>svg]:size-4 [&>svg]:shrink-0',
        className,
      ),
    },
    props,
  ),
  render,
  state: {
    slot: 'sidebar-group-action',
    sidebar: 'group-action',
  },
});

export const SidebarGroupContent = ({
  className,
  ...props
}: ComponentProps<'div'>) => (
  <div
    data-slot='sidebar-group-content'
    data-sidebar='group-content'
    className={ cn('w-full text-sm', className) }
    { ...props }
  />
);

export const SidebarMenu = ({ className, ...props }: ComponentProps<'ul'>) => (
  <ul
    data-slot='sidebar-menu'
    data-sidebar='menu'
    className={ cn('flex w-full min-w-0 flex-col gap-2', className) }
    { ...props }
  />
);

export const SidebarMenuItem = ({ className, ...props }: ComponentProps<'li'>) => (
  <li
    data-slot='sidebar-menu-item'
    data-sidebar='menu-item'
    className={ cn('group/menu-item relative', className) }
    { ...props }
  />
);

const sidebarMenuButtonVariants = cva(
  'peer/menu-button group/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm ring-sidebar-ring outline-hidden transition-[width,height,padding] group-has-data-[sidebar=menu-action]/menu-item:pr-8 group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-open:hover:bg-sidebar-accent data-open:hover:text-sidebar-accent-foreground data-active:bg-sidebar-accent data-active:font-medium data-active:text-sidebar-accent-foreground [&_svg]:size-4 [&_svg]:shrink-0 [&>span:last-child]:truncate',
  {
    variants: {
      variant: {
        default: 'hover:bg-sidebar-accent hover:text-sidebar-accent-foreground',
        outline:
          'bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]',
      },
      size: {
        default: 'h-8 text-sm',
        sm: 'h-7 text-xs',
        lg: 'h-12 text-sm',
        logo: 'h-16 text-sm group-data-[collapsible=icon]:p-0!',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  },
);

export const SidebarMenuButton = ({
  render,
  isActive = false,
  variant = 'default',
  size = 'default',
  tooltip,
  className,
  ...props
}: useRender.ComponentProps<'button'>
  & ComponentProps<'button'> & {
    isActive?: boolean;
    tooltip?: string | ComponentProps<typeof TooltipContent>;
  } & VariantProps<typeof sidebarMenuButtonVariants>) => {
  const { isMobile, state } = useSidebar();
  const comp = useRender({
    defaultTagName: 'button',
    props: mergeProps<'button'>(
      {
        className: cn(sidebarMenuButtonVariants({ variant, size }), className),
      },
      props,
    ),
    render: !tooltip ? render : <TooltipTrigger render={ render } />,
    state: {
      slot: 'sidebar-menu-button',
      sidebar: 'menu-button',
      size,
      active: isActive,
    },
  });

  if (!tooltip) {
    return comp;
  }

  if (typeof tooltip === 'string') {
    tooltip = {
      children: tooltip,
    };
  }

  return (
    <Tooltip>
      { comp }
      <TooltipContent
        side='right'
        align='center'
        hidden={ state !== 'collapsed' || isMobile }
        { ...tooltip }
      />
    </Tooltip>
  );
};

export const SidebarMenuAction = ({
  className,
  render,
  showOnHover = false,
  ...props
}: useRender.ComponentProps<'button'>
  & ComponentProps<'button'> & {
    showOnHover?: boolean;
  }) => useRender({
  defaultTagName: 'button',
  props: mergeProps<'button'>(
    {
      className: cn(
        'absolute top-1.5 right-1 flex aspect-square w-5 items-center justify-center rounded-md p-0 text-sidebar-foreground ring-sidebar-ring outline-hidden transition-transform group-data-[collapsible=icon]:hidden peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-2.5 peer-data-[size=sm]/menu-button:top-1 after:absolute after:-inset-2 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 md:after:hidden [&>svg]:size-4 [&>svg]:shrink-0',
        showOnHover
            && 'group-focus-within/menu-item:opacity-100 group-hover/menu-item:opacity-100 peer-data-active/menu-button:text-sidebar-accent-foreground aria-expanded:opacity-100 md:opacity-0',
        className,
      ),
    },
    props,
  ),
  render,
  state: {
    slot: 'sidebar-menu-action',
    sidebar: 'menu-action',
  },
});

export const SidebarMenuBadge = ({
  className,
  ...props
}: ComponentProps<'div'>) => (
  <div
    data-slot='sidebar-menu-badge'
    data-sidebar='menu-badge'
    className={ cn(
      'pointer-events-none absolute right-1 flex h-5 min-w-5 items-center justify-center rounded-md px-1 text-xs font-medium text-sidebar-foreground tabular-nums select-none group-data-[collapsible=icon]:hidden peer-hover/menu-button:text-sidebar-accent-foreground peer-data-[size=default]/menu-button:top-1.5 peer-data-[size=lg]/menu-button:top-2.5 peer-data-[size=sm]/menu-button:top-1 peer-data-active/menu-button:text-sidebar-accent-foreground',
      className,
    ) }
    { ...props }
  />
);

export const SidebarMenuSkeleton = ({
  className,
  showIcon = false,
  ...props
}: ComponentProps<'div'> & {
  showIcon?: boolean;
}) => {
  const [ width ] = useState(() => `${Math.floor(Math.random() * 40) + 50}%`);

  return (
    <div
      data-slot='sidebar-menu-skeleton'
      data-sidebar='menu-skeleton'
      className={ cn('flex h-8 items-center gap-2 rounded-md px-2', className) }
      { ...props }
    >
      { showIcon && (
        <Skeleton
          className='size-4 rounded-md'
          data-sidebar='menu-skeleton-icon'
        />
      ) }
      <Skeleton
        className='h-4 max-w-(--skeleton-width) flex-1'
        data-sidebar='menu-skeleton-text'
        style={
          {
            '--skeleton-width': width,
          } as CSSProperties
        }
      />
    </div>
  );
};

export const SidebarMenuSub = ({ className, ...props }: ComponentProps<'ul'>) => (
  <ul
    data-slot='sidebar-menu-sub'
    data-sidebar='menu-sub'
    className={ cn(
      'mx-3.5 flex min-w-0 translate-x-px flex-col gap-1 border-l border-sidebar-border px-2.5 py-0.5 group-data-[collapsible=icon]:hidden',
      className,
    ) }
    { ...props }
  />
);

export const SidebarMenuSubItem = ({
  className,
  ...props
}: ComponentProps<'li'>) => (
  <li
    data-slot='sidebar-menu-sub-item'
    data-sidebar='menu-sub-item'
    className={ cn('group/menu-sub-item relative', className) }
    { ...props }
  />
);

export const SidebarMenuSubButton = ({
  render,
  size = 'md',
  isActive = false,
  className,
  ...props
}: useRender.ComponentProps<'a'>
  & ComponentProps<'a'> & {
    size?: 'sm' | 'md';
    isActive?: boolean;
  }) => useRender({
  defaultTagName: 'a',
  props: mergeProps<'a'>(
    {
      className: cn(
        'flex h-7 min-w-0 -translate-x-px items-center gap-2 overflow-hidden rounded-md px-2 text-sidebar-foreground ring-sidebar-ring outline-hidden group-data-[collapsible=icon]:hidden hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[size=md]:text-sm data-[size=sm]:text-xs data-active:bg-sidebar-accent data-active:text-sidebar-accent-foreground [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0 [&>svg]:text-sidebar-accent-foreground',
        className,
      ),
    },
    props,
  ),
  render,
  state: {
    slot: 'sidebar-menu-sub-button',
    sidebar: 'menu-sub-button',
    size,
    active: isActive,
  },
});
