import { type ComponentProps } from 'react';
import { mergeProps } from '@base-ui/react/merge-props';
import { useRender } from '@base-ui/react/use-render';

import { cn } from '@/lib/utils.mjs';
import { ChevronRightIcon, MoreHorizontalIcon } from 'lucide-react';

export const Breadcrumb = ({ className, ...props }: ComponentProps<'nav'>) => (
  <nav
    aria-label='breadcrumb'
    data-slot='breadcrumb'
    className={ cn(className) }
    { ...props }
  />
);

export const BreadcrumbList = ({ className, ...props }: ComponentProps<'ol'>) => (
  <ol
    data-slot='breadcrumb-list'
    className={ cn(
      'flex flex-wrap items-center gap-1.5 text-sm wrap-break-word text-muted-foreground',
      className,
    ) }
    { ...props }
  />
);

export const BreadcrumbItem = ({ className, ...props }: ComponentProps<'li'>) => (
  <li
    data-slot='breadcrumb-item'
    className={ cn('inline-flex items-center gap-1', className) }
    { ...props }
  />
);

export const BreadcrumbLink = ({
  className,
  render,
  ...props
}: useRender.ComponentProps<'a'>) => useRender({
  defaultTagName: 'a',
  props: mergeProps<'a'>(
    {
      className: cn('transition-colors hover:text-foreground', className),
    },
    props,
  ),
  render,
  state: {
    slot: 'breadcrumb-link',
  },
});

export const BreadcrumbPage = ({ className, ...props }: ComponentProps<'span'>) => (
  <span
    data-slot='breadcrumb-page'
    role='link'
    aria-disabled='true'
    aria-current='page'
    className={ cn('font-normal text-foreground', className) }
    { ...props }
  />
);

export const BreadcrumbSeparator = ({
  children,
  className,
  ...props
}: ComponentProps<'li'>) => (
  <li
    data-slot='breadcrumb-separator'
    role='presentation'
    aria-hidden='true'
    className={ cn('[&>svg]:size-3.5', className) }
    { ...props }
  >
    { children ?? (
      <ChevronRightIcon />
    ) }
  </li>
);

export const BreadcrumbEllipsis = ({
  className,
  ...props
}: ComponentProps<'span'>) => (
  <span
    data-slot='breadcrumb-ellipsis'
    role='presentation'
    aria-hidden='true'
    className={ cn(
      'flex size-5 items-center justify-center [&>svg]:size-4',
      className,
    ) }
    { ...props }
  >
    <MoreHorizontalIcon />
    <span className='sr-only'>More</span>
  </span>
);

