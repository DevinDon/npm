import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * 合并 className：clsx 组合 + tailwind-merge 去冲突。
 * 所有组件样式类名的唯一入口（shadcn/ui 惯例）。
 */
export const cn = (...inputs: ClassValue[]) => twMerge(clsx(inputs));
