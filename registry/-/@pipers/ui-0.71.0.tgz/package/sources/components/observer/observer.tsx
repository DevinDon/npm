import { useEffect, useRef, type ComponentProps, type ReactNode } from 'react';

import { cn } from '@/lib/utils.mjs';

/** 视口哨兵属性 */
export type ObserverProps = Omit<ComponentProps<'div'>, 'children'> & {
  /** 哨兵进入视口时触发（无限滚动、曝光埋点等） */
  readonly onEnter: () => void;
  /** 根边界扩展，默认 '0px'（如 '200px' 表示提前触发） */
  readonly rootMargin?: string;
  /** 触发阈值，默认 0 */
  readonly threshold?: number | number[];
  /** 哨兵内容（通常为空占位） */
  readonly children?: ReactNode;
};

/**
 * 视口哨兵：IntersectionObserver 最小封装，进入视口时回调 onEnter
 *
 * 回调存 ref，回调变化不重建观察；卸载（或 rootMargin / threshold 变化）时断开观察器
 */
export const Observer = ({
  onEnter,
  rootMargin = '0px',
  threshold = 0,
  children,
  className,
  ...props
}: ObserverProps) => {
  const ref = useRef<HTMLDivElement>(null);
  const onEnterRef = useRef(onEnter);
  const optionsRef = useRef({ rootMargin, threshold });
  onEnterRef.current = onEnter;
  optionsRef.current = { rootMargin, threshold };
  // 数组阈值按内容比较，避免每次渲染重建观察器
  const thresholdKey = Array.isArray(threshold) ? threshold.join(',') : threshold;

  useEffect(
    () => {
      const element = ref.current;
      if (!element) {
        return undefined;
      }
      const options = optionsRef.current;
      const observer = new IntersectionObserver(
        entries => {
          if (entries.some(entry => entry.isIntersecting)) {
            onEnterRef.current();
          }
        },
        { rootMargin: options.rootMargin, threshold: options.threshold },
      );
      observer.observe(element);
      return () => observer.disconnect();
    },
    [ rootMargin, thresholdKey ],
  );

  return (
    <div ref={ ref } data-slot='observer' className={ cn('block', className) } { ...props }>
      { children }
    </div>
  );
};
