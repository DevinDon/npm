import { type ComponentProps } from 'react';

import { cn } from '@/lib/utils.mjs';

/** 折线形态的描边宽度（配合 non-scaling-stroke，缩放后仍为像素常量） */
const STROKE_WIDTH = 1.5;

/** 画布归一化宽度：横向按 0–100 归一，靠 preserveAspectRatio 拉伸到容器 */
const VIEW_WIDTH = 100;

/** 柱宽占格宽的比例 */
const BAR_RATIO = 0.6;

/** 折线点串：x 均分 0–100，y 由数据范围归一化到画布内 */
const toLinePoints = (data: readonly number[], height: number): string => {
  const inset = STROKE_WIDTH;
  const span = height - inset * 2;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const step = data.length > 1 ? VIEW_WIDTH / (data.length - 1) : 0;
  return data
    .map((value, index) => {
      const ratio = max === min ? 0.5 : (value - min) / (max - min);
      const x = data.length > 1 ? index * step : VIEW_WIDTH / 2;
      return `${x},${height - inset - ratio * span}`;
    })
    .join(' ');
};

/** 柱状矩形：贴底对齐、以数据最大值归一，负值按 0 处理 */
const toBars = (data: readonly number[], height: number) => {
  const max = Math.max(...data, 0);
  const slot = data.length > 0 ? VIEW_WIDTH / data.length : 0;
  const width = slot * BAR_RATIO;
  return data.map((value, index) => {
    const barHeight = max > 0 ? (Math.max(value, 0) / max) * height : 0;
    return {
      x: index * slot + (slot - width) / 2,
      y: height - barHeight,
      width,
      height: barHeight,
    };
  });
};

/** 迷你图属性 */
export type SparklineProps = Omit<ComponentProps<'svg'>, 'children'> & {
  /** 数据序列，从左到右排列 */
  readonly data: readonly number[];
  /** 高度像素，默认 32 */
  readonly height?: number;
  /** 形态：折线（默认）或柱状 */
  readonly variant?: 'line' | 'bar';
  /** 无障碍名称；缺省视为装饰性图形 */
  readonly label?: string;
};

/**
 * 迷你图：轻量 SVG 折线 / 柱状，不依赖图表库；颜色走 currentColor
 * （默认 text-primary，调用方可给其他语义色类名覆盖）
 */
export const Sparkline = ({
  data,
  height = 32,
  variant = 'line',
  label,
  className,
  ...props
}: SparklineProps) => (
  <svg
    data-slot='sparkline'
    data-variant={ variant }
    role='img'
    aria-label={ label }
    aria-hidden={ label ? undefined : true }
    viewBox={ `0 0 ${VIEW_WIDTH} ${height}` }
    preserveAspectRatio='none'
    className={ cn('block w-full text-primary', className) }
    style={ { height } }
    { ...props }
  >
    {
      variant === 'bar'
        ? toBars(data, height).map((bar, index) => (
          <rect
            key={ index }
            data-slot='sparkline-bar'
            x={ bar.x }
            y={ bar.y }
            width={ bar.width }
            height={ bar.height }
            fill='currentColor'
          />
        ))
        : (
          <polyline
            data-slot='sparkline-line'
            points={ toLinePoints(data, height) }
            fill='none'
            stroke='currentColor'
            strokeWidth={ STROKE_WIDTH }
            strokeLinecap='round'
            strokeLinejoin='round'
            vectorEffect='non-scaling-stroke'
          />
        )
    }
  </svg>
);
