import { type ComponentProps, type ReactNode } from 'react';

import { cn } from '@/lib/utils.mjs';

/** 单格上下文：提示与自定义渲染共用的定位信息 */
export type HeatmapCellContext = {
  /** 数值 */
  readonly value: number;
  /** 行索引（0 起） */
  readonly row: number;
  /** 列索引（0 起） */
  readonly col: number;
  /** 档位（getLevel 结果） */
  readonly level: number;
};

/** 热力图属性 */
export type HeatmapProps = Omit<ComponentProps<'div'>, 'children'> & {
  /** 行数 */
  readonly rows: number;
  /** 列数 */
  readonly cols: number;
  /** 每格数值，行优先展开（长度 rows × cols，缺位按 0 处理） */
  readonly values: readonly number[];
  /** 数值 → 色阶档位：档位数与阈值全由调用方决定，组件不分档 */
  readonly getLevel: (value: number, row: number, col: number) => number;
  /** 档位 → 类名：由调用方给语义色类名，组件不内置任何颜色 */
  readonly getLevelClassName?: (level: number) => string | undefined;
  /** 每格无障碍标签，缺省用数值本身 */
  readonly getCellLabel?: (value: number, row: number, col: number) => string;
  /** 每格悬浮提示（原生 title 属性），缺省无提示 */
  readonly getCellTitle?: (value: number, row: number, col: number) => string | undefined;
  /** 每格自定义渲染：只替换格子内部内容，格子元素与无障碍属性仍由组件给出 */
  readonly renderCell?: (cell: HeatmapCellContext) => ReactNode;
};

/**
 * 热力图网格：只负责 rows × cols 布局、档位回调与无障碍语义
 *
 * 档位级别写在格子 data-level 上，颜色由调用方经 getLevelClassName 或
 * `[data-level='...']` 选择器从语义令牌派生；逐格悬浮提示走 getCellTitle（原生 title），
 * 需要往格子内放内容时用 renderCell（不改变格子的 role 与 aria-label）
 */
export const Heatmap = ({
  rows,
  cols,
  values,
  getLevel,
  getLevelClassName,
  getCellLabel,
  getCellTitle,
  renderCell,
  className,
  ...props
}: HeatmapProps) => (
  <div
    data-slot='heatmap'
    role='grid'
    aria-rowcount={ rows }
    aria-colcount={ cols }
    className={ cn('grid gap-1', className) }
    style={ { gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` } }
    { ...props }
  >
    {
      Array.from({ length: rows }, (_, row) => (
        <div key={ row } role='row' data-slot='heatmap-row' className='contents'>
          {
            Array.from({ length: cols }, (_, col) => {
              const value = values[row * cols + col] ?? 0;
              const level = getLevel(value, row, col);
              return (
                <div
                  key={ col }
                  role='gridcell'
                  data-slot='heatmap-cell'
                  data-level={ level }
                  title={ getCellTitle?.(value, row, col) }
                  aria-label={ getCellLabel?.(value, row, col) ?? String(value) }
                  className={ cn('aspect-square rounded-[2px]', getLevelClassName?.(level)) }
                >
                  { renderCell?.({ value, row, col, level }) }
                </div>
              );
            })
          }
        </div>
      ))
    }
  </div>
);
