import { type ComponentProps, type ReactNode } from 'react';

import { cn } from '@/lib/utils.mjs';

/** 环形进度属性 */
export type RingProps = Omit<ComponentProps<'div'>, 'children'> & {
  /** 百分比（0–100，超出范围按边界截断） */
  readonly value: number;
  /** 外径像素，默认 40 */
  readonly size?: number;
  /** 环宽像素，默认 4 */
  readonly strokeWidth?: number;
  /** 环心内容（如百分比文本） */
  readonly children?: ReactNode;
};

/**
 * 环形进度：SVG 描边圆环，尺寸与环宽任意可配；颜色只用语义令牌（slot 类名可覆盖）
 *
 * 线性进度仍由 Progress 承担，本组件不改动 Progress 的对外 API
 */
export const Ring = ({ value, size = 40, strokeWidth = 4, children, className, ...props }: RingProps) => {
  const percent = Number.isFinite(value) ? Math.min(Math.max(value, 0), 100) : 0;
  const radius = Math.max((size - strokeWidth) / 2, 0);
  const circumference = 2 * Math.PI * radius;
  const dashOffset = circumference * (1 - percent / 100);

  return (
    <div
      data-slot='ring'
      role='progressbar'
      aria-valuemin={ 0 }
      aria-valuemax={ 100 }
      aria-valuenow={ percent }
      className={ cn('relative inline-flex shrink-0 items-center justify-center', className) }
      style={ { width: size, height: size } }
      { ...props }
    >
      <svg data-slot='ring-svg' aria-hidden='true' viewBox={ `0 0 ${size} ${size}` } className='size-full -rotate-90'>
        <circle
          data-slot='ring-track'
          cx={ size / 2 }
          cy={ size / 2 }
          r={ radius }
          fill='none'
          strokeWidth={ strokeWidth }
          className='stroke-muted'
        />
        <circle
          data-slot='ring-indicator'
          cx={ size / 2 }
          cy={ size / 2 }
          r={ radius }
          fill='none'
          strokeWidth={ strokeWidth }
          strokeLinecap='round'
          strokeDasharray={ circumference }
          strokeDashoffset={ dashOffset }
          className='stroke-primary transition-[stroke-dashoffset] duration-300'
        />
      </svg>
      {
        children
          ? (
            <div data-slot='ring-content' className='absolute inset-0 flex items-center justify-center'>
              { children }
            </div>
          )
          : null
      }
    </div>
  );
};
