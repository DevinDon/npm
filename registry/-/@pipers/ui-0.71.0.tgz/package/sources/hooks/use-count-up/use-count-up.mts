import { useEffect, useRef, useState } from 'react';

/** 默认动画时长（毫秒） */
const DEFAULT_DURATION = 600;

/** ease-out 缓动：1 - (1 - t)^3 */
const easeOut = (progress: number) => 1 - (1 - progress) ** 3;

/** 是否要求减少动效（prefers-reduced-motion） */
const prefersReducedMotion = () => (typeof window !== 'undefined'
  ? (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false)
  : false);

/**
 * 数字滚动入场：从 0 缓动到目标值，ease-out 收尾
 *
 * - 时长默认 600ms，可用第二参数覆盖；<= 0 表示不播放动画
 * - 尊重 prefers-reduced-motion：开启减少动效时直接返回目标值
 * - 目标值变化时从当前显示值继续滚动，不会跳回 0
 * - 返回未取整的连续值，展示前自行格式化（如 Math.round、toLocaleString）
 */
export const useCountUp = (value: number, duration = DEFAULT_DURATION): number => {
  const [ display, setDisplay ] = useState(() => (prefersReducedMotion() || duration <= 0 ? value : 0));
  const displayRef = useRef(display);
  const frameRef = useRef<number | null>(null);

  useEffect(
    () => {
      const from = displayRef.current;
      const settle = () => {
        displayRef.current = value;
        setDisplay(value);
      };
      if (prefersReducedMotion() || duration <= 0 || from === value) {
        settle();
        return undefined;
      }
      const delta = value - from;
      const start = performance.now();
      const tick = (now: number) => {
        const progress = Math.min((now - start) / duration, 1);
        const next = from + delta * easeOut(progress);
        displayRef.current = next;
        setDisplay(next);
        if (progress < 1) {
          frameRef.current = requestAnimationFrame(tick);
          return;
        }
        frameRef.current = null;
        displayRef.current = value;
      };
      frameRef.current = requestAnimationFrame(tick);
      return () => {
        if (frameRef.current !== null) {
          cancelAnimationFrame(frameRef.current);
          frameRef.current = null;
        }
      };
    },
    [ value, duration ],
  );

  return display;
};
