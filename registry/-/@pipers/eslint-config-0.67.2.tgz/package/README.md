# @pipers/eslint-config

Pipers 项目的共享 ESLint 配置（flat config）。

## 安装

```bash
pnpm add -D @pipers/eslint-config
```

## 使用

```ts
// eslint.config.mts
import pipersESLintConfig from '@pipers/eslint-config';

export default [
  // 全局 ignores 必须独立成对象放首位，否则只作用于该对象自身
  { ignores: [ 'eslint.config.mts' ] },
  ...pipersESLintConfig,
  {
    languageOptions: {
      parserOptions: {
        project: [ 'tsconfig.json', 'tsconfig.test.json' ],
        projectServices: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
  },
];
```

需要类型感知规则时，务必把用到的 tsconfig 都列进 `parserOptions.project`（测试用 `tsconfig.test.json` 与构建用 `tsconfig.json` 分开），否则测试文件会因缺少类型信息产生误报。

## 文档与变更

- 使用指南：https://github.com/DevinDon/pipers/blob/main/docs/README.md
- 变更记录（含破坏性变更与迁移对照）：https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md

## 许可

MIT © IInfinity
