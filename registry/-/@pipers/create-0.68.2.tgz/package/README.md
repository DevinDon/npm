# @pipers/create

`create-pipers` 脚手架：创建 Pipers 工作区、应用或模块。

## 使用

```bash
# 创建工作区（项目）
pnpm create pipers

# 或直接调用
npx create-pipers@latest
```

CLI 子命令：`project`（别名 `p`，创建工作区）· `application`（别名 `a`，创建应用）· `sync`（别名 `s`，同步技能）。

## 说明

- 模板由仓库中的示例应用生成（包内 `templates/` 为生成物，勿手改——改模板要改源）。
- 前后端成对创建时，后端应用名取「前端应用名 + `-api`」（如前端 `console` ↔ 后端 `console-api`）：模板按此后缀渲染前端对后端契约包的依赖。
- 生成的应用可直接 `pnpm install` 后运行；需要 Node.js 与 pnpm。

## 同步技能

把包内已渲染好的模板技能（`templates/project/.agents/skills/`）渲染后覆盖写入已有项目的 `.agents/skills/`，只动该目录，不碰其它文件：

```bash
# 同步到指定目录，或不传目录时用当前目录
pnpm create @pipers sync [directory]

# 试运行：只列出将写入的文件，不写入也不备份
pnpm create @pipers sync --dry-run
```

- 目标必须是 Pipers 项目（含 `package.json` 且依赖里有 `@pipers/*`）；项目名取自 `package.json` 的 `name`，应用名从 `packages/*/package.json` 的包名（`@<项目>/<应用>[-api]`）推导。
- 多应用项目默认取排序后的第一个应用渲染，并在输出中列出全部候选；可用 `-a, --application <name>` 显式指定。
- 默认覆盖前把同名文件备份到项目根下的 `temp/skills-backup-<时间戳>/`（`temp/` 已在项目 `.gitignore` 中），输出会告知备份位置。
- 未生成 `templates/` 时会提示先在仓库根执行 `pnpm action template`。

## 文档与变更

- 使用指南：<https://github.com/DevinDon/pipers/blob/main/docs/README.md>
- 变更记录（含破坏性变更与迁移对照）：<https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md>

## 许可

MIT © IInfinity
