# @pipers/core

Pipers 框架内核：用流式管道思想处理客户端请求的 TypeScript 后端框架——Pipeline 抽象、Operators 与 HTTP / WebSocket 传输实现。

## 安装

```bash
pnpm add @pipers/core
```

## 导入

```ts
// 框架内核：Pipeline 抽象、Operators、跨协议通用管道（路由 / JSON / YAML / BON / 观测 / 限流等）
import { Pipers, intoFinished, viaJSONEncoder } from '@pipers/core';

// HTTP 语义层（跨平台，浏览器可加载）：上下文类型、路由工厂、HTTP 管道
import { type HTTPContext, createHTTPRoute, viaHTTPDispatching } from '@pipers/core/http';

// 平台实现从平台子路径导入（含 node:* 依赖）
import { createNodeH1Pipers } from '@pipers/core/http/h1-node';
```

| 子路径 | 内容 |
|---|---|
| `@pipers/core` | Pipeline 抽象、Operators 与跨协议通用管道 |
| `@pipers/core/http` | HTTP 上下文、路由工厂、HTTP 管道（**无平台依赖**） |
| `@pipers/core/http/h1-node` · `@pipers/core/http/h2-node` | Node HTTP/1.1 与 HTTP/2 传输实现 |
| `@pipers/core/websocket` · `/websocket/over-h1` · `/websocket/over-h1-based-bon-protocol` | WebSocket 语义层与 h1 / BON 协议实现 |

## 文档与变更

- 使用指南：https://github.com/DevinDon/pipers/blob/main/docs/README.md
- 变更记录（含破坏性变更与迁移对照）：https://github.com/DevinDon/pipers/blob/main/docs/CHANGELOG.md

## 许可

MIT © IInfinity
